package com.elitera.stornova

import android.app.job.JobParameters
import android.app.job.JobService
import kotlin.concurrent.thread

class SnapJob : JobService() {
    override fun onStartJob(p: JobParameters?): Boolean {
        thread {
            try { if (Insights.hasUsage(this)) Insights.snapshot(this) } catch (e: Exception) { }
            jobFinished(p, false)
        }
        return true
    }

    override fun onStopJob(p: JobParameters?) = false
}
