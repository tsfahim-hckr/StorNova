package com.elitera.stornova

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Process
import android.os.storage.StorageManager
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

object Insights {
    private val icons = HashMap<String, String>()
    private const val DAY = 86400000L

    fun hasUsage(c: Context): Boolean {
        val ao = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }

    fun label(c: Context, p: String): String =
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(p, 0)).toString()

    fun icon(c: Context, p: String): String = icons.getOrPut(p) {
        try {
            val d = c.packageManager.getApplicationIcon(p)
            val b = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 72, 72); d.draw(Canvas(b))
            val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.PNG, 90, o)
            "data:image/png;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) { "" }
    }

    // package -> (total bytes, cache bytes)
    fun sizes(c: Context): Map<String, Pair<Long, Long>> {
        val ss = c.getSystemService(StorageStatsManager::class.java)
        val m = HashMap<String, Pair<Long, Long>>()
        for (a in c.packageManager.getInstalledApplications(0)) {
            try {
                val s = ss.queryStatsForPackage(StorageManager.UUID_DEFAULT, a.packageName, Process.myUserHandle())
                m[a.packageName] = Pair(s.appBytes + s.dataBytes, s.cacheBytes)
            } catch (e: Exception) { }
        }
        return m
    }

    private fun today() = System.currentTimeMillis() / DAY

    fun snapshot(c: Context, sz: Map<String, Pair<Long, Long>> = sizes(c)) {
        val sp = c.getSharedPreferences("snap", Context.MODE_PRIVATE)
        val o = JSONObject()
        sz.forEach { (k, v) -> o.put(k, v.first) }
        val ed = sp.edit().putString("d" + today(), o.toString())
        sp.all.keys.filter { it.startsWith("d") && it.substring(1).toLong() < today() - 14 }.forEach { ed.remove(it) }
        ed.apply()
    }

    fun growth(c: Context, sz: Map<String, Pair<Long, Long>>): String {
        val sp = c.getSharedPreferences("snap", Context.MODE_PRIVATE)
        val t = today()
        val old = sp.all.keys.map { it.substring(1).toLong() }.filter { it < t }.minOrNull()
            ?: return "{\"days\":0,\"items\":[]}"
        val base = JSONObject(sp.getString("d$old", "{}") ?: "{}")
        val list = ArrayList<JSONObject>()
        for ((p, v) in sz) {
            val g = v.first - base.optLong(p, v.first)
            if (g > 1048576L) list.add(JSONObject().put("n", label(c, p)).put("p", p).put("g", g).put("s", v.first).put("i", icon(c, p)))
        }
        list.sortByDescending { it.getLong("g") }
        return JSONObject().put("days", t - old).put("items", JSONArray(list.take(20))).toString()
    }

    fun unused(c: Context, sz: Map<String, Pair<Long, Long>>): String {
        val now = System.currentTimeMillis()
        val lim = now - 60L * DAY
        val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val last = HashMap<String, Long>()
        um.queryUsageStats(UsageStatsManager.INTERVAL_YEARLY, now - 400L * DAY, now)?.forEach {
            if (it.lastTimeUsed > (last[it.packageName] ?: 0L)) last[it.packageName] = it.lastTimeUsed
        }
        val pm = c.packageManager
        val arr = ArrayList<JSONObject>()
        for (a in pm.getInstalledApplications(0)) {
            val p = a.packageName
            val sys = (a.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (a.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (p == c.packageName || sys || pm.getLaunchIntentForPackage(p) == null) continue
            val inst = try { pm.getPackageInfo(p, 0).firstInstallTime } catch (x: Exception) { now }
            val l = last[p] ?: 0L
            if (l < lim && inst < lim) arr.add(JSONObject().put("n", pm.getApplicationLabel(a).toString()).put("p", p)
                .put("s", sz[p]?.first ?: 0L).put("l", l).put("i", icon(c, p)))
        }
        arr.sortByDescending { it.getLong("s") }
        return JSONArray(arr.take(60)).toString()
    }

    fun running(c: Context): String {
        val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = um.queryEvents(now - 3 * DAY, now)
        val e = UsageEvents.Event()
        val fg = HashMap<String, Boolean>()
        val act = HashMap<String, Long>()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            when (e.eventType) {
                19 -> fg[e.packageName] = true   // foreground service started
                20 -> fg[e.packageName] = false  // foreground service stopped
                1 -> act[e.packageName] = e.timeStamp // activity resumed
            }
        }
        val pm = c.packageManager
        fun item(p: String, t: Long): JSONObject? = try {
            JSONObject().put("n", pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()).put("p", p).put("t", t).put("i", icon(c, p))
        } catch (x: Exception) { null }
        val a = JSONArray()
        val b = JSONArray()
        fg.filter { it.value && it.key != c.packageName }.keys.forEach { p -> item(p, 0L)?.let { a.put(it) } }
        act.filter { now - it.value < 30 * 60000L && it.key != c.packageName && fg[it.key] != true }.entries
            .sortedByDescending { it.value }.take(25).forEach { en -> item(en.key, en.value)?.let { b.put(it) } }
        return JSONObject().put("fg", a).put("recent", b).toString()
    }
}
