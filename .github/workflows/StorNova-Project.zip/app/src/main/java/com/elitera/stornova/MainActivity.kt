package com.elitera.stornova

import android.Manifest
import android.app.Activity
import android.app.StatusBarManager
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.graphics.drawable.Icon
import android.widget.Toast
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val root: File = Environment.getExternalStorageDirectory()
    private var junkMap = HashMap<String, List<File>>()
    private val big = 50L * 1024 * 1024
    @Volatile private var lsGen = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.setBackgroundColor(0xFF070B1A.toInt())
        web.setOnApplyWindowInsetsListener { v, i ->
            v.setPadding(0, i.systemWindowInsetTop, 0, i.systemWindowInsetBottom); i
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        val sch = getSystemService(JobScheduler::class.java)
        if (sch.getPendingJob(1) == null) {
            sch.schedule(JobInfo.Builder(1, ComponentName(this, SnapJob::class.java)).setPeriodic(24L * 3600000L).build())
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.refresh&&refresh()", null)
    }

    private fun js(t: String, json: String) = runOnUiThread { web.evaluateJavascript("onNative('$t',$json)", null) }

    private fun hasFiles() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun size(f: File): Long = if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    inner class Bridge {
        @JavascriptInterface
        fun req(t: String) {
            thread { try { when (t) { "info" -> info(); "apps" -> apps(); "scan" -> scan(); "growth", "unused", "running" -> insight(t) } } catch (e: Exception) { } }
        }

        @JavascriptInterface
        fun ls(p: String) {
            thread { try { list(if (p.isEmpty()) root else File(p)) } catch (e: Exception) { } }
        }

        @JavascriptInterface
        fun act(t: String, a: String) {
            thread {
                try {
                    when (t) {
                        "usage" -> runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                        "files" -> runOnUiThread {
                            if (Build.VERSION.SDK_INT >= 30) startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                            else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
                        }
                        "appinfo" -> runOnUiThread { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$a"))) }
                        "del" -> {
                            val f = File(a)
                            if (f.isFile && f.canonicalPath.startsWith(root.canonicalPath)) {
                                val s = f.length(); if (f.delete()) js("done", "{\"freed\":$s}")
                            }
                        }
                        "deld" -> {
                            val f = File(a).canonicalFile
                            val r = root.canonicalPath
                            if (f.isDirectory && f.path != r && f.path.startsWith(r)) {
                                val s = size(f); f.deleteRecursively(); js("done", "{\"freed\":$s}")
                            }
                        }
                        "uninstall" -> runOnUiThread { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$a"))) }
                        "tile" -> addTile()
                        "clean" -> clean(a)
                    }
                } catch (e: Exception) { }
            }
        }
    }

    private fun info() {
        val st = StatFs(Environment.getDataDirectory().path)
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val o = JSONObject().put("total", st.totalBytes).put("free", st.availableBytes)
            .put("temp", (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0)
            .put("level", bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0)
            .put("model", Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL)
        js("info", o.toString())
    }

    private fun apps() {
        if (!Insights.hasUsage(this)) { js("apps", "{\"need\":\"usage\"}"); return }
        val sz = Insights.sizes(this)
        Insights.snapshot(this, sz)
        val list = ArrayList<JSONObject>()
        for ((p, v) in sz) {
            try { list.add(JSONObject().put("n", Insights.label(this, p)).put("p", p).put("s", v.first).put("c", v.second)) } catch (e: Exception) { }
        }
        list.sortByDescending { it.getLong("s") }
        val arr = JSONArray()
        list.take(40).forEach { it.put("i", Insights.icon(this, it.getString("p"))); arr.put(it) }
        js("apps", arr.toString())
    }

    private fun insight(t: String) {
        if (!Insights.hasUsage(this)) { js(t, "{\"need\":\"usage\"}"); return }
        val j = if (t == "running") Insights.running(this) else {
            val sz = Insights.sizes(this)
            if (t == "unused") Insights.unused(this, sz) else Insights.growth(this, sz)
        }
        js(t, j)
    }

    private fun addTile() = runOnUiThread {
        if (Build.VERSION.SDK_INT >= 33) {
            getSystemService(StatusBarManager::class.java).requestAddTileService(
                ComponentName(this, CleanTile::class.java), "StorNova",
                Icon.createWithResource(this, R.drawable.ic_tile), mainExecutor) { }
        } else {
            Toast.makeText(this, "Swipe down twice, tap the edit (pencil) icon and drag StorNova into the panel", Toast.LENGTH_LONG).show()
        }
    }

    private fun scan() {
        if (!hasFiles()) { js("scan", "{\"need\":\"files\"}"); return }
        val folders = ArrayList<Pair<String, Long>>()
        val files = ArrayList<Pair<String, Long>>()
        val jk = HashMap<String, ArrayList<File>>()
        fun walk(d: File, depth: Int): Long {
            val kids = d.listFiles() ?: return 0
            if (kids.isEmpty() && d != root) jk.getOrPut("empty") { ArrayList() }.add(d)
            var t = 0L
            for (f in kids) {
                if (f.isDirectory) {
                    val s = walk(f, depth + 1); t += s
                    if (depth < 2 && s > big) folders.add(f.path to s)
                } else {
                    val l = f.length(); t += l
                    if (l > big) files.add(f.path to l)
                    val n = f.name.lowercase(); val p = f.path.lowercase()
                    val k = when {
                        n.endsWith(".apk") -> "apk"
                        p.contains("/.thumbnails/") || p.contains("/.thumbs/") -> "thumb"
                        n.endsWith(".tmp") || n.endsWith(".temp") || n.endsWith(".log") || n.endsWith(".bak") -> "temp"
                        else -> null
                    }
                    if (k != null) jk.getOrPut(k) { ArrayList() }.add(f)
                }
            }
            return t
        }
        walk(root, 0)
        val own = listOfNotNull(cacheDir, externalCacheDir)
        val names = mapOf("apk" to "Old APK files", "thumb" to "Thumbnails", "temp" to "Temp & log files", "empty" to "Empty folders")
        val junk = JSONArray()
        val ownSize = own.sumOf { size(it) }
        junk.put(JSONObject().put("k", "cache").put("n", "StorNova cache").put("s", ownSize).put("c", 1))
        junkMap = HashMap(jk)
        for ((k, v) in jk) junk.put(JSONObject().put("k", k).put("n", names[k]).put("s", v.sumOf { if (it.isFile) it.length() else 0L }).put("c", v.size))
        fun arr(l: List<Pair<String, Long>>, n: Int) = JSONArray().also { a -> l.sortedByDescending { it.second }.take(n).forEach { a.put(JSONObject().put("p", it.first).put("s", it.second)) } }
        js("scan", JSONObject().put("folders", arr(folders, 15)).put("files", arr(files, 25)).put("junk", junk).toString())
    }

    private fun list(d0: File) {
        if (!hasFiles()) { js("ls", "{\"need\":\"files\"}"); return }
        val r = root.canonicalPath
        val d = d0.canonicalFile
        if (!d.path.startsWith(r) || !d.isDirectory) return
        val g = ++lsGen
        val kids = d.listFiles() ?: emptyArray()
        val dirs = kids.filter { it.isDirectory }.sortedBy { it.name.lowercase() }
        val fl = kids.filter { it.isFile }.sortedByDescending { it.length() }
        val arr = JSONArray()
        (dirs + fl).forEach {
            arr.put(JSONObject().put("n", it.name).put("p", it.path).put("d", it.isDirectory)
                .put("s", if (it.isFile) it.length() else -1L).put("m", it.lastModified()))
        }
        js("ls", JSONObject().put("p", d.path).put("root", r).put("items", arr).toString())
        for (x in dirs) {
            if (g != lsGen) return
            val s = size(x)
            js("lsz", JSONObject().put("p", x.path).put("s", s).toString())
        }
    }

    private fun clean(keys: String) {
        var freed = 0L
        for (k in keys.split(",")) {
            if (k == "cache") listOfNotNull(cacheDir, externalCacheDir).forEach { d -> d.listFiles()?.forEach { freed += size(it); it.deleteRecursively() } }
            else junkMap[k]?.forEach { f -> val s = if (f.isFile) f.length() else 0L; if (f.delete()) freed += s }
        }
        js("done", "{\"freed\":$freed}")
    }
}
