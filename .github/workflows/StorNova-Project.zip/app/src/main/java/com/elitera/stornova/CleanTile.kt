package com.elitera.stornova

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class CleanTile : TileService() {
    override fun onStartListening() {
        val t = qsTile ?: return
        val free = StatFs(Environment.getDataDirectory().path).availableBytes / 1073741824.0
        t.label = "StorNova"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = "%.1f GB free".format(free)
        t.state = Tile.STATE_ACTIVE
        t.updateTile()
    }

    override fun onClick() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            startActivityAndCollapse(i)
        }
    }
}
