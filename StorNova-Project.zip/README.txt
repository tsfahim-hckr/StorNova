StorNova project. Upload this zip to a GitHub repo root and add .github/workflows/build.yml (see build.yml). GitHub builds app-debug.apk.
