package com.elitera.stornova

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class LockActivity : Activity() {
    private var pkg = ""
    private val pin = StringBuilder()
    private lateinit var dots: TextView
    private lateinit var msg: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pkg = intent.getStringExtra("p") ?: ""
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(0xFF070B1A.toInt())
        root.setPadding(px(24), px(40), px(24), px(24))
        val ic = ImageView(this)
        try { ic.setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (e: Exception) { }
        root.addView(ic, LinearLayout.LayoutParams(px(64), px(64)))
        val name = try { Insights.label(this, pkg) } catch (e: Exception) { pkg }
        msg = TextView(this)
        msg.text = "Enter PIN to open $name"
        msg.setTextColor(0xFFEAF0FF.toInt()); msg.textSize = 16f; msg.gravity = Gravity.CENTER
        msg.setPadding(0, px(14), 0, px(6))
        root.addView(msg)
        dots = TextView(this)
        dots.setTextColor(0xFF22E3FF.toInt()); dots.textSize = 26f; dots.gravity = Gravity.CENTER
        dots.setPadding(0, px(6), 0, px(16)); dots.minHeight = px(56)
        root.addView(dots)
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "\u232B", "0", "\u2713")
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for (c in 0 until 3) {
                val k = keys[r * 3 + c]
                val bt = Button(this)
                bt.text = k; bt.textSize = 22f
                bt.setTextColor(0xFFEAF0FF.toInt()); bt.setBackgroundColor(0xFF161F45.toInt())
                bt.setOnClickListener { press(k) }
                val lp = LinearLayout.LayoutParams(px(84), px(64))
                lp.setMargins(px(6), px(6), px(6), px(6))
                row.addView(bt, lp)
            }
            root.addView(row)
        }
        setContentView(root)
    }

    private fun press(k: String) {
        if (k == "\u232B") {
            if (pin.isNotEmpty()) pin.deleteCharAt(pin.length - 1)
        } else if (k == "\u2713") {
            if (Lock.verify(this, pin.toString())) { Lock.ok = pkg; finish(); return }
            pin.setLength(0); msg.text = "Wrong PIN, try again"
        } else if (pin.length < 8) {
            pin.append(k)
        }
        dots.text = "\u25CF ".repeat(pin.length)
    }

    override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
