package com.elitera.stornova

import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import kotlin.concurrent.thread

class LockService : Service() {
    @Volatile private var run = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Insights.channel(this)
        val n = Insights.notif(this, "StorNova App Lock", "Protecting your locked apps")
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(2, n)
        if (!run) { run = true; thread { loop() } }
        return START_STICKY
    }

    override fun onDestroy() { run = false; super.onDestroy() }

    private fun loop() {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        var since = System.currentTimeMillis() - 1000
        var lastP = ""
        var lastT = 0L
        val e = UsageEvents.Event()
        while (run) {
            try {
                val now = System.currentTimeMillis()
                val ev = um.queryEvents(since, now)
                since = now - 300
                val set = Lock.locked(this)
                while (ev.hasNextEvent()) {
                    ev.getNextEvent(e)
                    if (e.eventType == 16) Lock.ok = ""
                    if (e.eventType != 1 || e.packageName == packageName) continue
                    val p = e.packageName
                    if (p != Lock.ok) Lock.ok = ""
                    if (p in set && p != Lock.ok && !(p == lastP && now - lastT < 1500)) {
                        lastP = p; lastT = now
                        startActivity(Intent(this, LockActivity::class.java).putExtra("p", p)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                    }
                }
            } catch (x: Exception) { }
            Thread.sleep(300)
        }
    }
}
