package com.elitera.stornova

import android.Manifest
import android.app.Activity
import android.app.StatusBarManager
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.graphics.drawable.Icon
import android.widget.Toast
import android.webkit.MimeTypeMap
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val root: File = Environment.getExternalStorageDirectory()
    private var junkMap = HashMap<String, List<File>>()
    private val big = 50L * 1024 * 1024
    @Volatile private var lsGen = 0
    @Volatile private var scanning = false
    private val queue = java.util.ArrayDeque<String>()
    private var qMode = ""
    private var qOpen = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.setBackgroundColor(0xFF070B1A.toInt())
        web.setOnApplyWindowInsetsListener { v, i ->
            v.setPadding(0, i.systemWindowInsetTop, 0, i.systemWindowInsetBottom); i
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        try {
            if (Lock.isOn(this) && Lock.hasPin(this) && Insights.hasUsage(this) && Settings.canDrawOverlays(this))
                startForegroundService(Intent(this, LockService::class.java))
        } catch (e: Exception) { }
        val sch = getSystemService(JobScheduler::class.java)
        if (sch.getPendingJob(1) == null) {
            sch.schedule(JobInfo.Builder(1, ComponentName(this, SnapJob::class.java)).setPeriodic(6L * 3600000L).build())
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.refresh&&refresh()", null)
        if (qOpen) { qOpen = false; web.postDelayed({ qNext() }, 700) }
    }

    private fun js(t: String, json: String) = runOnUiThread { web.evaluateJavascript("onNative('$t',$json)", null) }

    private fun hasFiles() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun size(f: File): Long = if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    inner class Bridge {
        @JavascriptInterface
        fun req(t: String) {
            thread { try { when (t) { "info" -> info(); "apps" -> apps(); "scan" -> scan(); "growth", "unused", "running" -> insight(t); "lock" -> lockState() } } catch (e: Exception) { } }
        }

        @JavascriptInterface
        fun ls(p: String) {
            thread { try { list(if (p.isEmpty()) root else File(p)) } catch (e: Exception) { } }
        }

        @JavascriptInterface
        fun act(t: String, a: String) {
            thread {
                try {
                    when (t) {
                        "usage" -> runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                        "files" -> runOnUiThread {
                            if (Build.VERSION.SDK_INT >= 30) startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                            else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
                        }
                        "appinfo" -> runOnUiThread { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$a"))) }
                        "del" -> {
                            val f = File(a)
                            if (f.isFile && f.canonicalPath.startsWith(root.canonicalPath)) {
                                val s = f.length(); if (f.delete()) js("done", "{\"freed\":$s}")
                            }
                        }
                        "deld" -> {
                            val f = File(a).canonicalFile
                            val r = root.canonicalPath
                            if (f.isDirectory && f.path != r && f.path.startsWith(r)) {
                                val s = size(f); f.deleteRecursively(); js("done", "{\"freed\":$s}")
                            }
                        }
                        "uninstall" -> runOnUiThread { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$a"))) }
                        "tile" -> addTile()
                        "open" -> openFile(a)
                        "queue" -> {
                            queue.clear()
                            qMode = a.substringBefore(":")
                            a.substringAfter(":").split(",").filter { it.isNotEmpty() }.forEach { queue.add(it) }
                            runOnUiThread { qNext() }
                        }
                        "qstop" -> { queue.clear(); qOpen = false; js("queue", "{\"left\":0}") }
                        "limit" -> {
                            val gb = a.toDoubleOrNull() ?: 0.0
                            getSharedPreferences("cfg", MODE_PRIVATE).edit().putLong("limit", (gb * 1073741824.0).toLong()).apply()
                            if (gb > 0 && Build.VERSION.SDK_INT >= 33) runOnUiThread {
                                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
                            }
                            info()
                        }
                        "setpin" -> { if (Regex("\\d{4,8}").matches(a)) { Lock.setPin(this@MainActivity, a); lockState() } }
                        "lockapp" -> Lock.setLocked(this@MainActivity, a.substringBeforeLast(":"), a.substringAfterLast(":") == "1")
                        "lkon" -> lockToggle(a == "1")
                        "clean" -> clean(a)
                    }
                } catch (e: Exception) { }
            }
        }
    }

    private fun info() {
        val st = StatFs(Environment.getDataDirectory().path)
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val o = JSONObject().put("limit", getSharedPreferences("cfg", MODE_PRIVATE).getLong("limit", 0L)).put("total", st.totalBytes).put("free", st.availableBytes)
            .put("temp", (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0)
            .put("level", bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0)
            .put("model", Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL)
        js("info", o.toString())
    }

    private fun apps() {
        if (!Insights.hasUsage(this)) { js("apps", "{\"need\":\"usage\"}"); return }
        val sz = Insights.sizes(this)
        Insights.snapshot(this, sz)
        val list = ArrayList<JSONObject>()
        for ((p, v) in sz) {
            try { list.add(JSONObject().put("n", Insights.label(this, p)).put("p", p).put("s", v.first).put("c", v.second)) } catch (e: Exception) { }
        }
        list.sortByDescending { it.getLong("s") }
        val arr = JSONArray()
        list.take(40).forEach { it.put("i", Insights.icon(this, it.getString("p"))); arr.put(it) }
        js("apps", arr.toString())
    }

    private fun insight(t: String) {
        if (!Insights.hasUsage(this)) { js(t, "{\"need\":\"usage\"}"); return }
        val j = if (t == "running") Insights.running(this) else {
            val sz = Insights.sizes(this)
            if (t == "unused") Insights.unused(this, sz) else Insights.growth(this, sz)
        }
        js(t, j)
    }

    private fun addTile() = runOnUiThread {
        if (Build.VERSION.SDK_INT >= 33) {
            getSystemService(StatusBarManager::class.java).requestAddTileService(
                ComponentName(this, CleanTile::class.java), "StorNova",
                Icon.createWithResource(this, R.drawable.ic_tile), mainExecutor) { }
        } else {
            Toast.makeText(this, "Swipe down twice, tap the edit (pencil) icon and drag StorNova into the panel", Toast.LENGTH_LONG).show()
        }
    }

    private fun scan() {
        if (scanning) return
        scanning = true
        try { scanNow() } finally { scanning = false }
    }

    private fun qNext() {
        val p = queue.pollFirst()
        if (p == null) { js("queue", "{\"left\":0}"); return }
        qOpen = true
        js("queue", "{\"left\":${queue.size + 1},\"mode\":\"$qMode\"}")
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p"))) } catch (e: Exception) { qOpen = false }
    }

    private fun openFile(path: String) {
        val f = File(path)
        if (!f.isFile || !f.canonicalPath.startsWith(root.canonicalPath)) return
        val u = Uri.Builder().scheme("content").authority("com.elitera.stornova.files").path(f.absolutePath).build()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        runOnUiThread {
            try {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (e: Exception) { Toast.makeText(this, "No app found to open this file", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun lockState(need: String = "") {
        val pm = packageManager
        val set = Lock.locked(this)
        val seen = HashSet<String>()
        val apps = ArrayList<JSONObject>()
        for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)) {
            val p = ri.activityInfo.packageName
            if (p == packageName || !seen.add(p)) continue
            apps.add(JSONObject().put("n", ri.loadLabel(pm).toString()).put("p", p).put("l", p in set).put("i", Insights.icon(this, p)))
        }
        apps.sortBy { it.getString("n").lowercase() }
        js("lock", JSONObject().put("pin", Lock.hasPin(this)).put("on", Lock.isOn(this)).put("need", need).put("apps", JSONArray(apps)).toString())
    }

    private fun lockToggle(on: Boolean) {
        val svc = Intent(this, LockService::class.java)
        if (!on) { Lock.setOn(this, false); stopService(svc); lockState(); return }
        when {
            !Lock.hasPin(this) -> lockState("pin")
            !Insights.hasUsage(this) -> {
                runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                lockState("usage")
            }
            !Settings.canDrawOverlays(this) -> {
                runOnUiThread { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
                lockState("overlay")
            }
            else -> { Lock.setOn(this, true); runOnUiThread { startForegroundService(svc) }; lockState() }
        }
    }

    private fun scanNow() {
        if (!hasFiles()) { js("scan", "{\"need\":\"files\"}"); return }
        val folders = ArrayList<Pair<String, Long>>()
        val files = ArrayList<Pair<String, Long>>()
        val jk = HashMap<String, ArrayList<File>>()
        fun walk(d: File, depth: Int): Long {
            val kids = d.listFiles() ?: return 0
            if (kids.isEmpty() && d != root) jk.getOrPut("empty") { ArrayList() }.add(d)
            var t = 0L
            for (f in kids) {
                if (f.isDirectory) {
                    val s = walk(f, depth + 1); t += s
                    if (depth < 2 && s > big) folders.add(f.path to s)
                } else {
                    val l = f.length(); t += l
                    if (l > big) files.add(f.path to l)
                    val n = f.name.lowercase(); val p = f.path.lowercase()
                    val k = when {
                        n.endsWith(".apk") -> "apk"
                        p.contains("/.thumbnails/") || p.contains("/.thumbs/") -> "thumb"
                        n.endsWith(".tmp") || n.endsWith(".temp") || n.endsWith(".log") || n.endsWith(".bak") -> "temp"
                        else -> null
                    }
                    if (k != null) jk.getOrPut(k) { ArrayList() }.add(f)
                }
            }
            return t
        }
        walk(root, 0)
        val own = listOfNotNull(cacheDir, externalCacheDir)
        val names = mapOf("apk" to "Old APK files", "thumb" to "Thumbnails", "temp" to "Temp & log files", "empty" to "Empty folders")
        val junk = JSONArray()
        val ownSize = own.sumOf { size(it) }
        junk.put(JSONObject().put("k", "cache").put("n", "StorNova cache").put("s", ownSize).put("c", 1))
        junkMap = HashMap(jk)
        for ((k, v) in jk) junk.put(JSONObject().put("k", k).put("n", names[k]).put("s", v.sumOf { if (it.isFile) it.length() else 0L }).put("c", v.size))
        fun arr(l: List<Pair<String, Long>>, n: Int) = JSONArray().also { a -> l.sortedByDescending { it.second }.take(n).forEach { a.put(JSONObject().put("p", it.first).put("s", it.second)) } }
        js("scan", JSONObject().put("folders", arr(folders, 15)).put("files", arr(files, 25)).put("junk", junk).toString())
    }

    private fun list(d0: File) {
        if (!hasFiles()) { js("ls", "{\"need\":\"files\"}"); return }
        val r = root.canonicalPath
        val d = d0.canonicalFile
        if (!d.path.startsWith(r) || !d.isDirectory) return
        val g = ++lsGen
        val kids = d.listFiles() ?: emptyArray()
        val dirs = kids.filter { it.isDirectory }.sortedBy { it.name.lowercase() }
        val fl = kids.filter { it.isFile }.sortedByDescending { it.length() }
        val arr = JSONArray()
        (dirs + fl).forEach {
            arr.put(JSONObject().put("n", it.name).put("p", it.path).put("d", it.isDirectory)
                .put("s", if (it.isFile) it.length() else -1L).put("m", it.lastModified()))
        }
        js("ls", JSONObject().put("p", d.path).put("root", r).put("items", arr).toString())
        for (x in dirs) {
            if (g != lsGen) return
            val s = size(x)
            js("lsz", JSONObject().put("p", x.path).put("s", s).toString())
        }
    }

    private fun clean(keys: String) {
        var freed = 0L
        for (k in keys.split(",")) {
            if (k == "cache") listOfNotNull(cacheDir, externalCacheDir).forEach { d -> d.listFiles()?.forEach { freed += size(it); it.deleteRecursively() } }
            else junkMap[k]?.forEach { f -> val s = if (f.isFile) f.length() else 0L; if (f.delete()) freed += s }
        }
        js("done", "{\"freed\":$freed}")
    }
}
