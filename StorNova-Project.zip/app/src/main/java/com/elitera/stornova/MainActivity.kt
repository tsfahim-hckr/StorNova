package com.elitera.stornova

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val root: File = Environment.getExternalStorageDirectory()
    private var junkMap = HashMap<String, List<File>>()
    private val big = 50L * 1024 * 1024

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.setBackgroundColor(0xFF070B1A.toInt())
        web.setOnApplyWindowInsetsListener { v, i ->
            v.setPadding(0, i.systemWindowInsetTop, 0, i.systemWindowInsetBottom); i
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.refresh&&refresh()", null)
    }

    private fun js(t: String, json: String) = runOnUiThread { web.evaluateJavascript("onNative('$t',$json)", null) }

    private fun hasFiles() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun size(f: File): Long = if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    inner class Bridge {
        @JavascriptInterface
        fun req(t: String) {
            thread { try { when (t) { "info" -> info(); "apps" -> apps(); "scan" -> scan() } } catch (e: Exception) { } }
        }

        @JavascriptInterface
        fun act(t: String, a: String) {
            thread {
                try {
                    when (t) {
                        "usage" -> runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                        "files" -> runOnUiThread {
                            if (Build.VERSION.SDK_INT >= 30) startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                            else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
                        }
                        "appinfo" -> runOnUiThread { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$a"))) }
                        "del" -> {
                            val f = File(a)
                            if (f.isFile && f.canonicalPath.startsWith(root.canonicalPath)) {
                                val s = f.length(); if (f.delete()) js("done", "{\"freed\":$s}")
                            }
                        }
                        "clean" -> clean(a)
                    }
                } catch (e: Exception) { }
            }
        }
    }

    private fun info() {
        val st = StatFs(Environment.getDataDirectory().path)
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val o = JSONObject().put("total", st.totalBytes).put("free", st.availableBytes)
            .put("temp", (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0)
            .put("level", bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0)
            .put("model", Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL)
        js("info", o.toString())
    }

    private fun apps() {
        val ao = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val ok = ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
        if (!ok) { js("apps", "{\"need\":\"usage\"}"); return }
        val ss = getSystemService(StorageStatsManager::class.java)
        val list = ArrayList<JSONObject>()
        for (a in packageManager.getInstalledApplications(0)) {
            try {
                val s = ss.queryStatsForPackage(StorageManager.UUID_DEFAULT, a.packageName, Process.myUserHandle())
                list.add(JSONObject().put("n", packageManager.getApplicationLabel(a).toString()).put("p", a.packageName)
                    .put("s", s.appBytes + s.dataBytes).put("c", s.cacheBytes))
            } catch (e: Exception) { }
        }
        list.sortByDescending { it.getLong("s") }
        val arr = JSONArray(); list.take(40).forEach { arr.put(it) }
        js("apps", arr.toString())
    }

    private fun scan() {
        if (!hasFiles()) { js("scan", "{\"need\":\"files\"}"); return }
        val folders = ArrayList<Pair<String, Long>>()
        val files = ArrayList<Pair<String, Long>>()
        val jk = HashMap<String, ArrayList<File>>()
        fun walk(d: File, depth: Int): Long {
            val kids = d.listFiles() ?: return 0
            if (kids.isEmpty() && d != root) jk.getOrPut("empty") { ArrayList() }.add(d)
            var t = 0L
            for (f in kids) {
                if (f.isDirectory) {
                    val s = walk(f, depth + 1); t += s
                    if (depth < 2 && s > big) folders.add(f.path to s)
                } else {
                    val l = f.length(); t += l
                    if (l > big) files.add(f.path to l)
                    val n = f.name.lowercase(); val p = f.path.lowercase()
                    val k = when {
                        n.endsWith(".apk") -> "apk"
                        p.contains("/.thumbnails/") || p.contains("/.thumbs/") -> "thumb"
                        n.endsWith(".tmp") || n.endsWith(".temp") || n.endsWith(".log") || n.endsWith(".bak") -> "temp"
                        else -> null
                    }
                    if (k != null) jk.getOrPut(k) { ArrayList() }.add(f)
                }
            }
            return t
        }
        walk(root, 0)
        val own = listOfNotNull(cacheDir, externalCacheDir)
        val names = mapOf("apk" to "Old APK files", "thumb" to "Thumbnails", "temp" to "Temp & log files", "empty" to "Empty folders")
        val junk = JSONArray()
        val ownSize = own.sumOf { size(it) }
        junk.put(JSONObject().put("k", "cache").put("n", "StorNova cache").put("s", ownSize).put("c", 1))
        junkMap = HashMap(jk)
        for ((k, v) in jk) junk.put(JSONObject().put("k", k).put("n", names[k]).put("s", v.sumOf { if (it.isFile) it.length() else 0L }).put("c", v.size))
        fun arr(l: List<Pair<String, Long>>, n: Int) = JSONArray().also { a -> l.sortedByDescending { it.second }.take(n).forEach { a.put(JSONObject().put("p", it.first).put("s", it.second)) } }
        js("scan", JSONObject().put("folders", arr(folders, 15)).put("files", arr(files, 25)).put("junk", junk).toString())
    }

    private fun clean(keys: String) {
        var freed = 0L
        for (k in keys.split(",")) {
            if (k == "cache") listOfNotNull(cacheDir, externalCacheDir).forEach { d -> d.listFiles()?.forEach { freed += size(it); it.deleteRecursively() } }
            else junkMap[k]?.forEach { f -> val s = if (f.isFile) f.length() else 0L; if (f.delete()) freed += s }
        }
        js("done", "{\"freed\":$freed}")
    }
}
