package com.elitera.stornova

import android.content.Context
import java.security.MessageDigest
import java.util.UUID

object Lock {
    @Volatile var ok = ""

    private fun sp(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)
    private fun hash(pin: String, salt: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }

    fun hasPin(c: Context) = sp(c).contains("h")
    fun setPin(c: Context, pin: String) {
        val salt = UUID.randomUUID().toString()
        sp(c).edit().putString("s", salt).putString("h", hash(pin, salt)).apply()
    }
    fun verify(c: Context, pin: String): Boolean {
        val s = sp(c)
        return hash(pin, s.getString("s", "") ?: "") == s.getString("h", null)
    }
    fun locked(c: Context): Set<String> = HashSet(sp(c).getStringSet("set", emptySet()) ?: emptySet())
    fun setLocked(c: Context, p: String, on: Boolean) {
        val n = HashSet(locked(c))
        if (on) n.add(p) else n.remove(p)
        sp(c).edit().putStringSet("set", n).apply()
    }
    fun isOn(c: Context) = sp(c).getBoolean("on", false)
    fun setOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("on", v).apply()
}
